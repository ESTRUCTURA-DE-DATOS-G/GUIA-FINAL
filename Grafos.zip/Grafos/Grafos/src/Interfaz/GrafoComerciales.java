package Interfaz;

import java.awt.*;

import Logica.AlgoritmoPrim;
import Logica.GrafoMat;
import Logica.GrafoMatriz;

import javax.swing.*;

public class GrafoComerciales extends javax.swing.JFrame {

    private GrafoMatriz<String> grafo = new GrafoMat<>();
    private GrafoMatriz<String> grafoMatriz;
    FondoPanel fondo = new FondoPanel();


    public GrafoComerciales(GrafoMatriz<String> Grafo, GrafoMatriz<String> GrafoMatriz) {
        this.setContentPane(fondo);
        initComponents();
        setIconImage(getIconImage());
        this.setTitle("Grafo Comerciales");
        this.setLocationRelativeTo(this);
        this.grafoMatriz = GrafoMatriz;
        this.grafo = Grafo;

        MostrarGrafo mostrarGrafo = new MostrarGrafo((GrafoMat<String>) grafo);
        mostrarGrafo.setSize(1076, 531);
        mostrarGrafo.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarGrafo, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        content = new javax.swing.JPanel();
        btn_Gijkstra = new javax.swing.JButton();
        btn_Prim = new javax.swing.JButton();
        btn_Warshall = new javax.swing.JButton();
        btn_Grafo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btn_Matriz = new javax.swing.JButton();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 102));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        content.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1076, Short.MAX_VALUE)
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 531, Short.MAX_VALUE)
        );

        btn_Gijkstra.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Gijkstra.setText("Dijkstra");
        btn_Gijkstra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_GijkstraActionPerformed(evt);
            }
        });

        btn_Prim.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Prim.setText("Prim");
        btn_Prim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_PrimActionPerformed(evt);
            }
        });

        btn_Warshall.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Warshall.setText("Warshall");
        btn_Warshall.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_WarshallActionPerformed(evt);
            }
        });

        btn_Grafo.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Grafo.setText("Mostrar Grafo");
        btn_Grafo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_GrafoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("OCR A Extended", 0, 36)); // NOI18N
        jLabel1.setText("CENTROS COMERCIALES DE BOGOTA");
        jLabel1.setForeground(Color.WHITE);

        btn_Matriz.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Matriz.setText("Matriz de Adyacencias");
        btn_Matriz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_MatrizActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 675, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(294, 294, 294))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(btn_Grafo, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_Matriz, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(btn_Gijkstra, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(btn_Prim, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62)
                        .addComponent(btn_Warshall, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addComponent(content, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(104, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(content, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_Grafo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_Matriz, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_Prim, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_Gijkstra, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_Warshall, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(12, 12, 12))
        );

        pack();
    }// </editor-fold>                        

    private void btn_WarshallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_WarshallActionPerformed
        MostrarWarshall mostrarWarshall = new MostrarWarshall((GrafoMat<String>) grafo);
        mostrarWarshall.setSize(1076, 531);
        mostrarWarshall.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarWarshall, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_WarshallActionPerformed

    private void btn_PrimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_PrimActionPerformed
        MostrarPrim mostrarPrim = new MostrarPrim((GrafoMat<String>) grafo);
        AlgoritmoPrim algoritmoPrim = new AlgoritmoPrim((GrafoMat<String>) grafo);
        mostrarPrim.setSize(1076, 531);
        mostrarPrim.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarPrim, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
        JOptionPane.showMessageDialog(null, algoritmoPrim.getResultado(), "Prim", 1);
    }//GEN-LAST:event_btn_PrimActionPerformed

    private void btn_GijkstraActionPerformed(java.awt.event.ActionEvent evt) {                                            
        MostrarDijkstra mostrarDijkstra = new MostrarDijkstra((GrafoMat<String>) grafo);
        mostrarDijkstra.setSize(1076, 531);
        mostrarDijkstra.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarDijkstra, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }                                            

    private void btn_MatrizActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_MatrizActionPerformed
        MatrizAdyacencia mostrarMatriz = new MatrizAdyacencia((GrafoMatriz<String>) grafoMatriz);
        mostrarMatriz.setSize(1076, 531);
        mostrarMatriz.setLocation(0, 0);
        content.removeAll();
        content.add(mostrarMatriz, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_MatrizActionPerformed

    private void btn_GrafoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_GrafoActionPerformed
        MostrarGrafo mostrarGrafo = new MostrarGrafo((GrafoMat<String>) grafo);
        mostrarGrafo.setSize(1076, 531);
        mostrarGrafo.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarGrafo, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_GrafoActionPerformed


    // Variables declaration - do not modify                     
    private javax.swing.JButton btn_Gijkstra;
    private javax.swing.JButton btn_Grafo;
    private javax.swing.JButton btn_Matriz;
    private javax.swing.JButton btn_Prim;
    private javax.swing.JButton btn_Warshall;
    private javax.swing.JPanel content;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration

class FondoPanel extends JPanel {

    private Image imagen;

    public void paint(Graphics g) {
        imagen = new ImageIcon(getClass().getResource("/Imagenes/Fondo.jpeg")).getImage();
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        setOpaque(false);

        super.paint(g);
    }
}

@Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/Icono.jpeg"));
        return retValue;
    }


}
