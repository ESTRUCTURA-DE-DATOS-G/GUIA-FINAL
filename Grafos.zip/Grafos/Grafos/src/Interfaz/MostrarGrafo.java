package Interfaz;

import Logica.GrafoMat;
import Logica.GrafoMatriz;

import java.awt.*;
import java.util.Random;

public class MostrarGrafo<E> extends javax.swing.JPanel {

    GrafoMatriz<E> grafo = new GrafoMat<>();

    public MostrarGrafo(GrafoMat<E> Grafo) {
        this.setPreferredSize(new Dimension(800, 600));
        grafo=Grafo;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int n = grafo.orden();
        int width = getWidth();
        int height = getHeight();
        int padding = 20; // Espacio mínimo entre nodos

        // Calcular las posiciones de los nodos de forma aleatoria
        Point[] puntos = new Point[n];
        String[] labels = new String[n];
        FontMetrics fm = g.getFontMetrics();
        Random rand = new Random();

        for (int i = 0; i < n; i++) {
            labels[i] = grafo.obtenerVertice(i).toString();
            int labelWidth = fm.stringWidth(labels[i]) + 10; // Ancho del nodo basado en el texto
            int nodeSize = Math.max(labelWidth, 30); // Tamaño mínimo del nodo

            boolean overlap;
            int x, y;
            do {
                overlap = false;
                x = rand.nextInt(width - nodeSize) + nodeSize / 2;
                y = rand.nextInt(height - nodeSize) + nodeSize / 2;

                for (int j = 0; j < i; j++) {
                    int dx = x - puntos[j].x;
                    int dy = y - puntos[j].y;
                    if (Math.sqrt(dx * dx + dy * dy) < (nodeSize + padding)) {
                        overlap = true;
                        break;
                    }
                }
            } while (overlap);

            puntos[i] = new Point(x, y);
        }

        // Dibujar aristas y pesos
        int[][] matriz = grafo.obtenerMatrizAdyacencia();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (matriz[i][j] != GrafoMat.num) { // Asumiendo que `num` representa la ausencia de arista
                    int x1 = puntos[i].x;
                    int y1 = puntos[i].y;
                    int x2 = puntos[j].x;
                    int y2 = puntos[j].y;
                    g.setColor(Color.BLACK);
                    g.drawLine(x1, y1, x2, y2);

                    // Dibujar el peso de la arista con fondo blanco
                    String peso = String.valueOf(matriz[i][j]);
                    int pesoWidth = fm.stringWidth(peso);
                    int pesoHeight = fm.getHeight();
                    int nodeSize = Math.max(fm.stringWidth(labels[i]) + 10, 30);
                    int offsetX = (y2 - y1) / 20; // Desplazamiento en x menor y proporcional al tamaño del nodo
                    int offsetY = (x1 - x2) / 20; // Desplazamiento en y menor y proporcional al tamaño del nodo
                    int pesoX = (x1 + x2) / 2 - pesoWidth / 2 + offsetX;
                    int pesoY = (y1 + y2) / 2 - pesoHeight / 2 + offsetY;

                    g.setColor(Color.WHITE);
                    g.fillRect(pesoX - 2, pesoY - pesoHeight + 2, pesoWidth + 4, pesoHeight);
                    g.setColor(Color.BLACK);
                    g.drawString(peso, pesoX, pesoY);
                }
            }
        }

        // Dibujar vértices
        for (int i = 0; i < n; i++) {
            String label = labels[i];
            int labelWidth = fm.stringWidth(label) + 10;
            int nodeSize = Math.max(labelWidth, 30); // Tamaño mínimo del nodo

            int x = puntos[i].x - nodeSize / 2;
            int y = puntos[i].y - nodeSize / 2;

            g.setColor(new Color(177, 57, 255)); // Morado claro
            g.fillOval(x, y, nodeSize, nodeSize);
            g.setColor(Color.BLACK);
            g.drawOval(x, y, nodeSize, nodeSize);
            g.drawString(label, puntos[i].x - fm.stringWidth(label) / 2, puntos[i].y + fm.getAscent() / 2);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 1077, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 531, Short.MAX_VALUE)
        );
    }// </editor-fold>

    // Variables declaration - do not modify
    // End of variables declaration


}