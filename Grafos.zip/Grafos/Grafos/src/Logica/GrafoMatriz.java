package Logica;

import java.util.ArrayList;

public interface GrafoMatriz<E> {

    void insertarVertice(E x);
    E obtenerVertice(int pos);
    void insertarArista(int verInicial, int verFinal, int costo);
    int costoArista(int verInicial, int verFinal);
    int orden();
    ArrayList<E> sucesores(int v);
    int num=99;

    public int[][] obtenerMatrizAdyacencia();
}
