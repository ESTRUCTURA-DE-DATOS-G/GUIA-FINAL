package Logica;

public class AlgoritmoFloyd {

    private int [][] pesos;
    private int [][] traza; //Guarda indice minimo
    private int [][] d;
    private int n;

    public void algoritmoFloyd(GrafoMat<String> grafo){
        n = grafo.orden();
        pesos = grafo.obtenerMatrizAdyacencia();
        d = new int [n][n];
        traza = new int[n][n];
        algoritmoFloyd();
    }

    public String casosNodos(int vertice){
        String nombre ="";
        switch (vertice){
            case 0:
                nombre="Plaza Imperial";
                break;
            case 1:
                nombre="Portal 80";
                break;
            case 2:
                nombre="Diverplaza";
                break;
            case 3:
                nombre="Titan Plaza";
                break;
            case 4:
                nombre="Nuestro Bogota";
                break;
            case 5:
                nombre="Hayuelos";
                break;
            case 6:
                nombre="Multiplaza";
                break;
            case 7:
                nombre="El Eden";
                break;
            case 8:
                nombre="Plaza Central";
                break;
            case 9:
                nombre="Centro Mayor";
                break;
            case 10:
                nombre="El Ensueño";
                break;
            case 11:
                nombre="Mercurio";
                break;
            case 12:
                nombre="UMB";
                break;
        }
        return nombre;
    }

    public void algoritmoFloyd(){
        //Matriz inicial es la de pesos
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                d[i][j] = pesos[i][j];
                traza[i][j] = -1; //Indica cual camino mas corto es el arco
            }
        }

        //Camino minimo de un vertice a si mismo: 0
        for (int i = 0; i < n; i++) {
            d[i][i] = 0;
            for(int k = 0; k < n; k++){
                for(int j = 0; j < n; j++){
                    if((d[i][k] + d[k][j] < d[i][j])){ //Nuevo Minimo
                        d[i][j] = d[i][k] + d[k][j];
                        traza[i][j] = k;
                    }
                }
            }
        }
    }

    public String recuperarCamino(int verticeInicial, int verticeFinal) {
        if (verticeInicial == verticeFinal) {
            return casosNodos(verticeInicial);
        }

        int intermedio = traza[verticeInicial][verticeFinal];
        if (intermedio == -1) {
            return casosNodos(verticeInicial) + " -> " + casosNodos(verticeFinal);
        } else {
            return recuperarCamino(verticeInicial, intermedio) + " -> " + recuperarCamino(intermedio, verticeFinal);
        }
    }

    public int distanciaMinima(int verticeInicial, int verticeFinal) {
        return d[verticeInicial][verticeFinal];
    }
}

