package Logica;

import java.util.ArrayList;

public class GrafoMat<E> implements GrafoMatriz<E> {

    private int aristas[][] = new int[100][100];
    private ArrayList<E> vertices = new ArrayList<>();

    public GrafoMat() {
        for (int i = 0; i < aristas.length; i++) {
            for (int j = 0; j < aristas.length; j++) {
                if (i != j) {
                    aristas[i][j] = num;
                }
            }
        }
    }

    @Override
    public void insertarVertice(E x) {
        vertices.add(x);
    }

    @Override
    public E obtenerVertice(int pos) {
        if (valida(pos)) {
            return vertices.get(pos);
        }
        return null;
    }

    @Override
    public void insertarArista(int verInicial, int verFinal, int costo) {
        if (valida(verInicial) && valida(verFinal)) {
            aristas[verInicial][verFinal] = costo;
        }
    }

    @Override
    public int costoArista(int verInicial, int verFinal) {
        if (valida(verInicial) && valida(verFinal)) {
            return aristas[verInicial][verFinal];
        }
        return -1;
    }

    @Override
    public int orden() {
        return vertices.size();
    }

    @Override
    public ArrayList<E> sucesores(int v) {
        ArrayList<E> suc = new ArrayList<>();
        if (valida(v)) {
            for (int i = 0; i < vertices.size(); i++) {
                if (aristas[v][i] != num && i != v) {
                    suc.add(obtenerVertice(i));
                }
            }
        }
        return suc;
    }
    
    @Override
    public int[][] obtenerMatrizAdyacencia() {
        int n = vertices.size();
        int[][] matriz = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = aristas[i][j];
            }
        }
        return matriz;
    }
    
    private boolean valida(int verInicial) {
        if (verInicial >= 0 && verInicial < orden()) {
            return true;
        }
        return false;
    }
}
