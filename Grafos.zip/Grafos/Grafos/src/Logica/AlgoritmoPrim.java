package Logica;

import java.util.ArrayList;
import java.util.List;

public class AlgoritmoPrim {

    private int[][] Pesos;
    private int n; // vértice origen y número de vértices
    private GrafoMat<String> grafo;
    private StringBuilder resultado; // Usar StringBuilder para concatenar cadenas de manera eficiente
    private List<int[]> arbolExpansion; // Para almacenar las aristas del árbol de expansión mínima

    public AlgoritmoPrim(GrafoMat<String> grafo) {
        this.grafo = grafo;
        n = grafo.orden();
        Pesos = grafo.obtenerMatrizAdyacencia();
        resultado = new StringBuilder(); // Inicializar StringBuilder
        arbolExpansion = new ArrayList<>();
        arbolExpansionPrim();
    }

    public String casosNodos(int vertice){
        String nombre ="";
        switch (vertice){
            case 0:
                nombre="Plaza Imperial";
                break;
            case 1:
                nombre="Portal 80";
                break;
            case 2:
                nombre="Diverplaza";
                break;
            case 3:
                nombre="Titan Plaza";
                break;
            case 4:
                nombre="Nuestro Bogota";
                break;
            case 5:
                nombre="Hayuelos";
                break;
            case 6:
                nombre="Multiplaza";
                break;
            case 7:
                nombre="El Eden";
                break;
            case 8:
                nombre="Plaza Central";
                break;
            case 9:
                nombre="Centro Mayor";
                break;
            case 10:
                nombre="El Ensueño";
                break;
            case 11:
                nombre="Mercurio";
                break;
            case 12:
                nombre="UMB";
                break;
        }
        return nombre;
    }

    public void arbolExpansionPrim() // implementación del algoritmo
    {

        int longMin, menor;
        int z;
        int[] coste = new int[n];
        int[] masCerca = new int[n];
        boolean[] W = new boolean[n];
        for (int i = 0; i < n; i++) {
            W[i] = false; // conjunto vacío
        }
        longMin = 0;
        W[0] = true; //se parte del vértice 0
        // inicialmente, coste[i] es la arista (0,i)
        for (int i = 1; i < n; i++) {
            coste[i] = Pesos[0][i];
            masCerca[i] = 0;
        }
        for (int i = 1; i < n; i++) { // busca vértice z de V-W más cercano,
            // de menor longitud de arista, a algún vértice de W
            menor = Integer.MAX_VALUE; // Inicializar menor con el valor máximo posible
            z = -1; // Inicializar z con un valor inválido
            for (int j = 1; j < n; j++) {
                if (!W[j] && coste[j] < menor) {
                    menor = coste[j];
                    z = j;
                }
            }
            if (z == -1) {
                throw new IllegalStateException("No se pudo encontrar un vértice adecuado");
            }
            longMin += menor;
            // Almacenar el resultado del arco
            arbolExpansion.add(new int[]{masCerca[z], z});
            resultado.append("V").append(casosNodos(masCerca[z])).append(" -> ").append(casosNodos(z)).append(", Peso: ").append(menor).append("\n");
            W[z] = true; // vértice z se añade al conjunto W
            coste[z] = grafo.num; // grafo.num debería ser un valor muy alto
            // debido a la incorporación de z,
            // se ajusta coste[] para el resto de vértices
            for (int j = 1; j < n; j++) {
                if (!W[j] && Pesos[z][j] < coste[j]) {
                    coste[j] = Pesos[z][j];
                    masCerca[j] = z;
                }
            }
        }

    }

    public String getResultado() {

        return resultado.toString();
    }

    public List<int[]> getArbolExpansion() {

        return arbolExpansion;
    }
}
