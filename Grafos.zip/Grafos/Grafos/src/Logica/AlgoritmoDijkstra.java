package Logica;

public class AlgoritmoDijkstra {
    private int matriz[][];
    private int ultimo[]; // último vértice visitado
    private int costosMinimos[]; // Costos mínimos guardados
    private boolean visitados[]; // Vértices ya visitados
    private int s, n; // s origen

    public void dijkstra(GrafoMat<String> grafo, int s) {
        n = grafo.orden();
        this.s = s;
        matriz = grafo.obtenerMatrizAdyacencia();
        ultimo = new int[n];
        costosMinimos = new int[n];
        visitados = new boolean[n];
        caminoMinimo();
    }
    public String casosNodos(int vertice){
        String nombre ="";
        switch (vertice){
            case 0:
                nombre="Plaza Imperial";
                break;
            case 1:
                nombre="Portal 80";
                break;
            case 2:
                nombre="Diverplaza";
                break;
            case 3:
                nombre="Titan Plaza";
                break;
            case 4:
                nombre="Nuestro Bogota";
                break;
            case 5:
                nombre="Hayuelos";
                break;
            case 6:
                nombre="Multiplaza";
                break;
            case 7:
                nombre="El Eden";
                break;
            case 8:
                nombre="Plaza Central";
                break;
            case 9:
                nombre="Centro Mayor";
                break;
            case 10:
                nombre="El Ensueño";
                break;
            case 11:
                nombre="Mercurio";
                break;
            case 12:
                nombre="UMB";
                break;
        }
        return nombre;
    }
    public void caminoMinimo() {
        for (int i = 0; i < n; i++) {
            visitados[i] = false;
            costosMinimos[i] = matriz[s][i];
            ultimo[i] = s;
        }
        visitados[s] = true;
        costosMinimos[s] = 0;

        for (int i = 0; i < n - 1; i++) {
            int vertice = minimo(); // Selecciona vértice

            visitados[vertice] = true;

            for (int w = 0; w < n; w++) {
                if (!visitados[w]) {
                    if (costosMinimos[vertice] + matriz[vertice][w] < costosMinimos[w]) {
                        costosMinimos[w] = costosMinimos[vertice] + matriz[vertice][w];
                        ultimo[w] = vertice;
                    }
                }
            }
        }
    }

    public int minimo() {
        int min = Integer.MAX_VALUE;
        int vertice = -1;
        for (int j = 0; j < n; j++) {
            if (!visitados[j] && costosMinimos[j] <= min) {
                min = costosMinimos[j];
                vertice = j;
            }
        }
        return vertice;
    }

    public String recuperarCamino(int vertice) {
        if (vertice == s) {
            return casosNodos(s);
        } else {
            return recuperarCamino(ultimo[vertice]) + "->" + casosNodos(vertice);
        }
    }

    public int getCostosMinimos(int destino) {
        return costosMinimos[destino];
    }
}
