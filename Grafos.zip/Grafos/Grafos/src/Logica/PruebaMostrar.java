package Logica;

import javax.swing.*;
import java.awt.*;
import Logica.GrafoMat;
import Logica.GrafoMatriz;

public class PruebaMostrar<E> extends JPanel {

    GrafoMatriz<E> grafo = new GrafoMat<>();
    public PruebaMostrar(GrafoMat<E> Grafo) {
        this.setPreferredSize(new Dimension(800, 600));
        grafo=Grafo;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int n = grafo.orden();
        int radius = 200; // Radio del círculo
        int centerX = getWidth() / 2;
        int centerY = getHeight() / 2;

        // Calcular las posiciones de los nodos en un círculo
        Point[] puntos = new Point[n];
        for (int i = 0; i < n; i++) {
            double angle = 2 * Math.PI * i / n;
            int x = centerX + (int) (radius * Math.cos(angle));
            int y = centerY + (int) (radius * Math.sin(angle));
            puntos[i] = new Point(x, y);
        }

        // Dibujar aristas
        int[][] matriz = grafo.obtenerMatrizAdyacencia();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (matriz[i][j] != GrafoMat.num) { // Asumiendo que `num` representa la ausencia de arista
                    int x1 = puntos[i].x;
                    int y1 = puntos[i].y;
                    int x2 = puntos[j].x;
                    int y2 = puntos[j].y;
                    g.drawLine(x1, y1, x2, y2);
                    g.drawString(String.valueOf(matriz[i][j]), (x1 + x2) / 2, (y1 + y2) / 2);
                }
            }
        }

        // Dibujar vértices
        for (int i = 0; i < n; i++) {
            int x = puntos[i].x;
            int y = puntos[i].y;
            g.setColor(Color.RED);
            g.fillOval(x - 15, y - 15, 30, 30);
            g.setColor(Color.BLACK);
            g.drawString(grafo.obtenerVertice(i).toString(), x - 5, y + 5);
        }
    }
}


