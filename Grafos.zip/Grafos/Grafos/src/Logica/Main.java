package Logica;

import Interfaz.GrafoComerciales;
import Interfaz.MatrizAdyacencia;
import Interfaz.MostrarGrafo;

import javax.swing.table.DefaultTableModel;

public class Main {

    public static void main(String args[]) {
        GrafoMat<String> grafo = new GrafoMat<>();
        GrafoMatriz<String> grafoMatriz = crear(grafo);
        GrafoComerciales mostrarVentana = new GrafoComerciales((GrafoMat<String>) grafo, (GrafoMatriz<String>) grafoMatriz);
        mostrarVentana.setVisible(true);
    }

    public static GrafoMatriz<String> crear(GrafoMat<String> grafo) {

        grafo.insertarVertice("Plaza Imperial"); //0
        grafo.insertarVertice("Portal 80"); //1
        grafo.insertarVertice("Diverplaza"); //2
        grafo.insertarVertice("Titan Plaza"); //3
        grafo.insertarVertice("Nuestro Bogota"); //4
        grafo.insertarVertice("Hayuelos"); //5
        grafo.insertarVertice("Multiplaza"); //6
        grafo.insertarVertice("El Eden"); //7
        grafo.insertarVertice("Plaza Central"); //8
        grafo.insertarVertice("Centro Mayor"); //9
        grafo.insertarVertice("El Ensueño"); //10
        grafo.insertarVertice("Mercurio"); //11
        grafo.insertarVertice("UMB"); //12

        // Plaza Imperial
        grafo.insertarArista(0, 9, 23);
        grafo.insertarArista(9, 0, 23);
        grafo.insertarArista(0, 1, 7);
        grafo.insertarArista(1, 0, 7);
        grafo.insertarArista(0, 5, 12);
        grafo.insertarArista(5, 0, 12);
        grafo.insertarArista(0, 7, 16);
        grafo.insertarArista(7, 0, 16);
        grafo.insertarArista(0, 3, 8);
        grafo.insertarArista(3, 0, 8);

        // Portal 80
        grafo.insertarArista(1, 2, 3);
        grafo.insertarArista(2, 1, 3);
        grafo.insertarArista(1, 4, 5);
        grafo.insertarArista(4, 1, 5);
        grafo.insertarArista(1, 9, 45);
        grafo.insertarArista(9, 1, 45);

        // Diverplaza
        grafo.insertarArista(2, 3, 5);
        grafo.insertarArista(3, 2, 5);
        grafo.insertarArista(2, 4, 3);
        grafo.insertarArista(4, 2, 3);
        grafo.insertarArista(2, 10, 49);
        grafo.insertarArista(10, 2, 49);
        grafo.insertarArista(2, 11, 24);
        grafo.insertarArista(11, 2, 24);

        // Titan Plaza
        grafo.insertarArista(3, 4, 8);
        grafo.insertarArista(4, 3, 8);
        grafo.insertarArista(3, 6, 8);
        grafo.insertarArista(6, 3, 8);
        grafo.insertarArista(3, 8, 10);
        grafo.insertarArista(8, 3, 10);

        // Nuestro Bogota
        grafo.insertarArista(4, 5, 3);
        grafo.insertarArista(5, 4, 3);
        grafo.insertarArista(4, 8, 8);
        grafo.insertarArista(8, 4, 8);

        // Hayuelos
        grafo.insertarArista(5, 6, 2);
        grafo.insertarArista(6, 5, 2);
        grafo.insertarArista(5, 7, 4);
        grafo.insertarArista(7, 5, 4);
        grafo.insertarArista(5, 11, 18);
        grafo.insertarArista(11, 5, 18);

        // Multiplaza
        grafo.insertarArista(6, 7, 3);
        grafo.insertarArista(7, 6, 3);

        // El Eden
        grafo.insertarArista(7, 8, 3);
        grafo.insertarArista(8, 7, 3);
        grafo.insertarArista(7, 10, 10);
        grafo.insertarArista(10, 7, 10);
        grafo.insertarArista(7, 11, 15);
        grafo.insertarArista(11, 7, 15);

        // Plaza Central
        grafo.insertarArista(8, 9, 7);
        grafo.insertarArista(9, 8, 7);
        grafo.insertarArista(8, 10, 9);
        grafo.insertarArista(10, 8, 9);
        grafo.insertarArista(8, 11, 16);
        grafo.insertarArista(11, 8, 16);

        // Centro Mayor
        grafo.insertarArista(9, 10, 6);
        grafo.insertarArista(10, 9, 6);
        grafo.insertarArista(9, 11, 11);
        grafo.insertarArista(11, 9, 11);

        // El Ensueño
        grafo.insertarArista(10, 11, 7);
        grafo.insertarArista(11, 10, 7);

        // UMB
        grafo.insertarArista(12, 1, 14);
        grafo.insertarArista(1, 12, 14);
        grafo.insertarArista(12, 4, 12);
        grafo.insertarArista(4, 12, 12);

        return grafo;
    }
}



