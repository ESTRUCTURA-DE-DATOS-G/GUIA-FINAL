package Logica;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class RecorridoAnchura {

    public String BFS(Grafo grafo, Object nodoInicial) {
        if (!grafo.ExisteVertice(nodoInicial)) {
            return "El nodo inicial no existe en el grafo.";
        }

        StringBuilder resultado = new StringBuilder();
        Set<Object> visitados = new HashSet<>();
        Queue<NodoGrafo> cola = new LinkedList<>();

        NodoGrafo inicial = grafo.primero;
        while (inicial != null && !inicial.dato.equals(nodoInicial)) {
            inicial = inicial.siguiente;
        }

        if (inicial == null) {
            return "El nodo inicial no se encuentra en el grafo.";
        }

        cola.add(inicial);
        visitados.add(nodoInicial);

        while (!cola.isEmpty()) {
            NodoGrafo actual = cola.poll();
            resultado.append(actual.dato).append(" ");

            for (Arista adyacente : actual.lista.getAdyacencias()) {
                if (!visitados.contains(adyacente.destino)) {
                    NodoGrafo vecino = grafo.primero;
                    while (vecino != null && !vecino.dato.equals(adyacente.destino)) {
                        vecino = vecino.siguiente;
                    }
                    if (vecino != null && !visitados.contains(vecino.dato)) {
                        cola.add(vecino);
                        visitados.add(vecino.dato);
                    }
                }
            }
        }

        return resultado.toString().trim();
    }
}




