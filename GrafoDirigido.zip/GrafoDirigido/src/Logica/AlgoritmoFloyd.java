package Logica;

import java.util.concurrent.RecursiveAction;
import java.util.concurrent.ForkJoinPool;

public class AlgoritmoFloyd {

    private int [][] pesos;
    private int [][] traza; // Guarda índice mínimo
    private int [][] d;
    private int n;
    private static final int INF = Integer.MAX_VALUE; // Define un valor grande como "infinito"

    public void algoritmoFloyd(GrafoMat<String> grafo) {
        n = grafo.orden();
        pesos = grafo.obtenerMatrizAdyacencia();
        d = new int[n][n];
        traza = new int[n][n];
        algoritmoFloyd();
    }

    public String casosNodos(int vertice) {
        String nombre = "";
        switch (vertice) {
            case 0: nombre = "Vertice 1"; break;
            case 1: nombre = "Vertice 2"; break;
            case 2: nombre = "Vertice 3"; break;
            case 3: nombre = "Vertice 4"; break;
            case 4: nombre = "Vertice 5"; break;
            case 5: nombre = "Vertice 6"; break;
            case 6: nombre = "Vertice 7"; break;
            case 7: nombre = "Vertice 8"; break;
            case 8: nombre = "Vertice 9"; break;
        }
        return nombre;
    }

    public void algoritmoFloyd() {
        // Matriz inicial es la de pesos
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                d[i][j] = pesos[i][j];
                traza[i][j] = -1; // Indica cuál camino más corto es el arco
            }
        }

        // Camino mínimo de un vértice a sí mismo: 0
        for (int i = 0; i < n; i++) {
            d[i][i] = 0;
        }

        // Crear un ForkJoinPool
        ForkJoinPool pool = new ForkJoinPool();
        for (int k = 0; k < n; k++) {
            pool.invoke(new UpdateDistancesTask(d, traza, n, k));
        }
    }

    static class UpdateDistancesTask extends RecursiveAction {
        int[][] dist;
        int[][] traza;
        int V;
        int k;

        UpdateDistancesTask(int[][] dist, int[][] traza, int V, int k) {
            this.dist = dist;
            this.traza = traza;
            this.V = V;
            this.k = k;
        }

        @Override
        protected void compute() {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    if (dist[i][k] != INF && dist[k][j] != INF && (dist[i][k] + dist[k][j] < dist[i][j])) { // Nuevo mínimo
                        dist[i][j] = dist[i][k] + dist[k][j];
                        traza[i][j] = k;
                    }
                }
            }
        }
    }

    public String recuperarCamino(int verticeInicial, int verticeFinal) {
        if (verticeInicial == verticeFinal) {
            return casosNodos(verticeInicial);
        }

        int intermedio = traza[verticeInicial][verticeFinal];
        if (intermedio == -1) {
            return casosNodos(verticeInicial) + " -> " + casosNodos(verticeFinal);
        } else {
            return recuperarCamino(verticeInicial, intermedio) + " -> " + recuperarCamino(intermedio, verticeFinal);
        }
    }

    public int distanciaMinima(int verticeInicial, int verticeFinal) {
        return d[verticeInicial][verticeFinal];
    }
}
