package Logica;


import java.util.LinkedList;
import java.util.List;

public class ListaAdyacencias {
    private List<Arista> adyacencias;

    public ListaAdyacencias() {
        this.adyacencias = new LinkedList<>();
    }

    public void NuevaAdyacencia(Object destino) {
        this.adyacencias.add(new Arista(destino));
    }

    public void NuevaAdyacencia(Object destino, float peso) {
        this.adyacencias.add(new Arista(destino, peso));
    }

    public List<Arista> getAdyacencias() {
        return adyacencias;
    }

    @Override
    public String toString() {
        return adyacencias.toString();
    }
}

