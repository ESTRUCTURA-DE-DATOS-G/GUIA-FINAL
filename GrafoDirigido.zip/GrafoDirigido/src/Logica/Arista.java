package Logica;

public class Arista {
    public Object destino;
    public float peso;

    public Arista(Object destino) {
        this.destino = destino;
        this.peso = 0;
    }

    public Arista(Object destino, float peso) {
        this.destino = destino;
        this.peso = peso;
    }

    @Override
    public String toString() {

        return "(" + destino.toString() + ", " + peso + ")";
    }
}


