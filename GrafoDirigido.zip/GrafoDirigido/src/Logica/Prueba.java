package Logica;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

public class Prueba<E> {

//    public ArrayList<E> recorridoBFS(GrafoMat<E> grafo, E inicio) {
//        ArrayList<E> recorrido = new ArrayList<>();
//        boolean[] visitado = new boolean[grafo.orden()];
//        Queue<E> cola = new ArrayDeque<>();
//
//        // Encontrar el índice del vértice inicial
//        int indexInicio = grafo.getVertices().indexOf(inicio);
//        if (indexInicio == -1) {
//            return recorrido; // Retorna lista vacía si el vértice inicial no existe
//        }
//
//        cola.add(inicio);
//        visitado[indexInicio] = true;
//
//        while (!cola.isEmpty()) {
//            E actual = cola.poll();
//            recorrido.add(actual);
//
//            // Obtener sucesores del vértice actual
//            ArrayList<E> sucesores = grafo.sucesores(grafo.getVertices().indexOf(actual));
//            for (E sucesor : sucesores) {
//                int indexSucesor = grafo.getVertices().indexOf(sucesor);
//                if (!visitado[indexSucesor]) {
//                    cola.add(sucesor);
//                    visitado[indexSucesor] = true;
//                }
//            }
//        }
//
//        return recorrido;
//    }
}


//import java.util.LinkedList;
//import java.util.Queue;
//
//public class Prueba {
//
//    public String recorridoAnchura(Grafo grafo, Object inicio) {
//        StringBuilder resultado = new StringBuilder();
//
//        if (!grafo.ExisteVertice(inicio)) {
//            resultado.append("El vértice de inicio no existe en el grafo.");
//            return resultado.toString();
//        }
//
//        boolean[] visitado = new boolean[grafo.numeroDeVertices()];
//        Queue<Object> cola = new LinkedList<>();
//
//        // Marcar el vértice de inicio como visitado y agregarlo a la cola
//        int indiceInicio = grafo.numVertice(inicio.toString());
//        visitado[indiceInicio] = true;
//        cola.offer(inicio);
//
//        while (!cola.isEmpty()) {
//            // Sacar el vértice de la cola y agregarlo al resultado
//            Object actual = cola.poll();
//            resultado.append(actual).append(" ");
//
//            // Obtener los vértices adyacentes del vértice actual y agregarlos a la cola si no han sido visitados
//            NodoGrafo nodoActual = grafo.getNodoGrafo(grafo.numVertice(actual.toString()));
//            Arco adyacente = nodoActual.lista.primero;
//            while (adyacente != null) {
//                int indiceDestino = grafo.numVertice(adyacente.destino.toString());
//                if (!visitado[indiceDestino]) {
//                    visitado[indiceDestino] = true;
//                    cola.offer(adyacente.destino);
//                }
//                adyacente = adyacente.siguiente;
//            }
//        }
//
//        return resultado.toString();
//    }
//
//
//}