package Logica;


public class Grafo {

    public NodoGrafo primero;
    private NodoGrafo ultimo;

    public Grafo() {
        primero = null;
        ultimo = null;
    }

    public boolean GrafoVacio() {
        return primero == null;
    }

    public int numeroDeVertices() {
        int count = 0;
        NodoGrafo temporal = primero;
        while (temporal != null) {
            count++;
            temporal = temporal.siguiente;
        }
        return count;
    }

    public boolean ExisteVertice(Object Dato) {
        boolean existe = false;
        if (!GrafoVacio()) {
            NodoGrafo temporal = primero;
            while (temporal != null && !existe) {
                if (temporal.dato.toString().equals(Dato.toString())) {
                    existe = true;
                }
                temporal = temporal.siguiente;
            }
        }
        return existe;
    }

    public void NuevaArista(Object Origen, Object Destino) {
        if (ExisteVertice(Origen) && ExisteVertice(Destino)) {
            NodoGrafo posicion = primero;
            while (!posicion.dato.equals(Origen.toString())) {
                posicion = posicion.siguiente;
            }
            posicion.lista.NuevaAdyacencia(Destino);
        }
    }

    public void NuevaArista(Object Origen, Object Destino, float Peso) {
        if (ExisteVertice(Origen) && ExisteVertice(Destino)) {
            NodoGrafo posicion = primero;
            while (!posicion.dato.equals(Origen.toString())) {
                posicion = posicion.siguiente;
            }
            posicion.lista.NuevaAdyacencia(Destino, Peso);
        }
    }

    public void NuevoNodo(Object Dato) {
        if (!ExisteVertice(Dato)) {
            NodoGrafo nodo = new NodoGrafo(Dato);
            if (GrafoVacio()) {
                primero = nodo;
                ultimo = nodo;
            } else {
                if (Dato.toString().compareTo(primero.dato.toString()) <= 0) {
                    nodo.siguiente = primero;
                    primero = nodo;
                } else if (Dato.toString().compareTo(ultimo.dato.toString()) >= 0) {
                    ultimo.siguiente = nodo;
                    ultimo = nodo;
                } else {
                    NodoGrafo temporal = primero;
                    while (temporal.siguiente != null && Dato.toString().compareTo(temporal.siguiente.dato.toString()) > 0) {
                        temporal = temporal.siguiente;
                    }
                    nodo.siguiente = temporal.siguiente;
                    temporal.siguiente = nodo;
                }
            }
        }
    }

    public int numVertice(String nombre) {
        int indice = 0;
        NodoGrafo temporal = primero;
        while (temporal != null) {
            if (temporal.dato.toString().equals(nombre)) {
                return indice;
            }
            temporal = temporal.siguiente;
            indice++;
        }
        return -1; // Retorna -1 si no se encuentra el vértice
    }

    public NodoGrafo getNodoGrafo(int index) {
        NodoGrafo temporal = primero;
        int currentIndex = 0;
        while (temporal != null) {
            if (currentIndex == index) {
                return temporal;
            }
            temporal = temporal.siguiente;
            currentIndex++;
        }
        return null; // Retorna null si no se encuentra el índice
    }

    @Override
    public String toString() {
        String cadena = "";
        NodoGrafo temporal = primero;
        while (temporal != null) {
            cadena = cadena + temporal.toString() + "\n";
            temporal = temporal.siguiente;
        }
        return cadena;
    }



}
