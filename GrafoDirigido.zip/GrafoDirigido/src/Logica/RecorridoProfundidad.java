package Logica;

import java.util.*;

public class RecorridoProfundidad {
/*
    public int[] recorrerProf(Grafo grafo, String org) throws Exception {

        int CLAVE = -1;
        int v, w;

        Stack<Integer> pila = new Stack<>();
        int[] m;
        m = new int[grafo.numeroDeVertices()];

        // Inicializa los vértices como no marcados
        v = grafo.numVertice(org);
        if (v < 0) throw new Exception("Vértice origen no existe");

        for (int i = 0; i < grafo.numeroDeVertices(); i++) {
            m[i] = CLAVE++;
        }

        m[v] = 0; // vértice origen queda marcado
        pila.push(v); // push (insertar en la pila)

        while (!pila.isEmpty()) {
            Integer cw;
            cw = pila.pop(); // pop (quitar de la pila)
            w = cw.intValue();
            System.out.println("Vértice " + grafo.getNodoGrafo(w).dato + " visitado");

            // Obtener la lista de adyacencias del vértice w
            ArrayList<Arco> adyacentes = grafo.getNodoGrafo(w).lista.getAdyacentes();
            for (Arco ck : adyacentes) {
                int k = ck.getDestino(); // vértice adyacente
                if (m[k] == CLAVE) {
                    pila.push(k); // push (insertar en la pila)
                    m[k] = 1; // vértice queda marcado
                }
            }
        }
        System.out.println(Arrays.toString(m));
        return m;
    }

 */
    /*
    public String recorridoProfundidad(Grafo grafo, Object inicio) {
        StringBuilder resultado = new StringBuilder();

        if (!grafo.ExisteVertice(inicio)) {
            resultado.append("El vértice de inicio no existe en el grafo.");
            return resultado.toString();
        }

        Stack<Object> pila = new Stack<>();
        boolean[] visitado = new boolean[grafo.numeroDeVertices()];

        pila.push(inicio);

        while (!pila.isEmpty()) {
            Object actual = pila.pop();
            int indice = grafo.numVertice(actual.toString());

            if (!visitado[indice]) {
                resultado.append(actual).append(" ");

                visitado[indice] = true;

                NodoGrafo nodoActual = grafo.getNodoGrafo(indice);
                Arco adyacente = nodoActual.lista.primero;

                while (adyacente != null) {
                    if (!visitado[grafo.numVertice(adyacente.destino.toString())]) {
                        pila.push(adyacente.destino);
                    }
                    adyacente = adyacente.siguiente;
                }
            }
        }

        return resultado.toString();
    }
*/
    public String recorridoProfundidad(Grafo grafo, Object inicio) {
        StringBuilder resultado = new StringBuilder();

        if (!grafo.ExisteVertice(inicio)) {
            resultado.append("El vértice de inicio no existe en el grafo.");
            return resultado.toString();
        }

        boolean[] visitado = new boolean[grafo.numeroDeVertices()];
        Stack<Object> pila = new Stack<>();
        Map<Object, Integer> verticeToIndex = new HashMap<>();
        int index = 0;
        for (NodoGrafo nodo = grafo.primero; nodo != null; nodo = nodo.siguiente) {
            verticeToIndex.put(nodo.dato, index++);
        }

        // Marcar el vértice de inicio como visitado y agregarlo a la pila
        int indiceInicio = verticeToIndex.get(inicio);
        visitado[indiceInicio] = true;
        pila.push(inicio);

        while (!pila.isEmpty()) {
            // Sacar el vértice de la pila y agregarlo al resultado
            Object actual = pila.pop();
            resultado.append(actual).append(" ");

            // Obtener los vértices adyacentes del vértice actual y agregarlos a la pila si no han sido visitados
            NodoGrafo nodoActual = grafo.getNodoGrafo(verticeToIndex.get(actual));
            for (Arista adyacente : nodoActual.lista.getAdyacencias()) {
                int indiceDestino = verticeToIndex.get(adyacente.destino);
                if (!visitado[indiceDestino]) {
                    visitado[indiceDestino] = true;
                    pila.push(adyacente.destino);
                }
            }
        }

        return resultado.toString().trim(); // Quitar el último espacio adicional
    }
}