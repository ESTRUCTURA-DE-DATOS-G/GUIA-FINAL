package Logica;

public class NodoGrafo {
    Object dato;
    NodoGrafo siguiente;
    ListaAdyacencias lista;

    public NodoGrafo(Object dato) {
        this.dato = dato;
        this.siguiente = null;
        this.lista = new ListaAdyacencias();
    }

    @Override
    public String toString() {
        return dato.toString() + " -> " + lista.toString();
    }
}