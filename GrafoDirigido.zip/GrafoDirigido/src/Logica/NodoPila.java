package Logica;

public class NodoPila {
    Object elemento;
    NodoPila siguiente;

    // Constructor
    public NodoPila(Object x) {
        elemento = x;
        siguiente = null;
    }
}
