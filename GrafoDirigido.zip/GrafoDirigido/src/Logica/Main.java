package Logica;


import Interfaz.GrafoComerciales;
import Interfaz.MatrizAdyacencia;
import Interfaz.MostrarGrafo;

import javax.swing.table.DefaultTableModel;

public class Main {

        public static void main(String args[]) {
                
                Grafo Lista = new Grafo();
                Grafo grafoLista = GrafoLista(Lista);

                GrafoMat<String> grafo = new GrafoMat<>();
                GrafoMatriz<String> grafoMatriz = crear(grafo);

                GrafoComerciales mostrarVentana = new GrafoComerciales((GrafoMat<String>) grafo,
                        (GrafoMatriz<String>) grafoMatriz, grafoLista);
                mostrarVentana.setVisible(true);

        }

        public static Grafo GrafoLista(Grafo Lista){

                Lista.NuevoNodo("1");
                Lista.NuevoNodo("2");
                Lista.NuevoNodo("3");
                Lista.NuevoNodo("4");
                Lista.NuevoNodo("5");
                Lista.NuevoNodo("6");
                Lista.NuevoNodo("7");
                Lista.NuevoNodo("8");
                Lista.NuevoNodo("9");

                // Vertice 1
                Lista.NuevaArista("1", "2", 1);
                Lista.NuevaArista("1", "3", 2);

                // Vertice 2
                Lista.NuevaArista("2", "3", 1);
                Lista.NuevaArista("2", "5", 2);
                Lista.NuevaArista("2", "4", 3);

                // Vertice 3
                Lista.NuevaArista("3", "4", 2);
                Lista.NuevaArista("3", "5", 2);

                // Vertice 4
                Lista.NuevaArista("4", "7", 5);
                Lista.NuevaArista("4", "6", 3);

                // Vertice 5
                Lista.NuevaArista("5", "4", 3);

                // Vertice 6
                Lista.NuevaArista("6", "5", 1);
                Lista.NuevaArista("6", "7", 1);
                Lista.NuevaArista("6", "8", 2);

                // Vertice 7
                Lista.NuevaArista("7", "9", 1);

                // Vertice 8
                Lista.NuevaArista("8", "7", 3);
                Lista.NuevaArista("8", "6", 2);
                Lista.NuevaArista("8", "9", 5);

                return Lista;

        }

        public static GrafoMatriz<String> crear(GrafoMat<String> grafo) {

                grafo.insertarVertice("1"); //0
                grafo.insertarVertice("2"); //1
                grafo.insertarVertice("3"); //2
                grafo.insertarVertice("4"); //3
                grafo.insertarVertice("5"); //4
                grafo.insertarVertice("6"); //5
                grafo.insertarVertice("7"); //6
                grafo.insertarVertice("8"); //7
                grafo.insertarVertice("9"); //8


                // Vertice 1
                grafo.insertarArista(0, 1, 1);
                grafo.insertarArista(0, 2, 2);

                //Vertice 2
                grafo.insertarArista(1, 2, 1);
                grafo.insertarArista(1, 4, 2);
                grafo.insertarArista(1, 3, 3);

                //Vertice 3
                grafo.insertarArista(2, 3, 2);
                grafo.insertarArista(2, 4, 2);


                //Vertice 4
                grafo.insertarArista(3, 6, 5);
                grafo.insertarArista(3, 5, 3);


                //Vertice 5
                grafo.insertarArista(4, 3, 3);


                // Vertice 6
                grafo.insertarArista(5, 4, 1);
                grafo.insertarArista(5, 6, 1);
                grafo.insertarArista(5, 7, 2);

                // Vertice 7
                grafo.insertarArista(6, 8,1 );


                // Vertice 8
                grafo.insertarArista(7, 6, 3);
                grafo.insertarArista(7, 5, 2);
                grafo.insertarArista(7, 8, 5);

                return grafo;
        }
}

