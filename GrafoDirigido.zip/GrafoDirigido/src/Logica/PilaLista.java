package Logica;

public class PilaLista {
    private NodoPila cima; // La cima de la pila

    // Constructor
    public PilaLista() {
        cima = null;
    }

    // Métodos
    public boolean pilaVacia() {
        return cima == null;
    }

    public void insertar(Object elemento) {
        NodoPila nuevo;
        nuevo = new NodoPila(elemento);
        nuevo.siguiente = cima;
        cima = nuevo;
    }

    public Object quitar() throws Exception {
        if (pilaVacia()) throw new Exception("Pila vacía, no se puede extraer.");
        Object aux = cima.elemento;
        cima = cima.siguiente;
        return aux;
    }
}
