package Logica;

public class AlgoritmoMaximos{
    private int matriz[][];
    private int ultimo[]; // último vértice visitado
    private int costosMaximos[]; // Costos máximos guardados
    private boolean visitados[]; // Vértices ya visitados
    private int s, n; // s origen

    public void dijkstraMaximo(GrafoMat<String> grafo, int s) {
        n = grafo.orden();
        this.s = s;
        matriz = grafo.obtenerMatrizAdyacencia();
        ultimo = new int[n];
        costosMaximos = new int[n];
        visitados = new boolean[n];
        caminoMaximo();
    }

    public String casosNodos(int vertice){
        String nombre = "";
        switch (vertice){
            case 0:
                nombre = "Vertice 1";
                break;
            case 1:
                nombre = "Vertice 2";
                break;
            case 2:
                nombre = "Vertice 3";
                break;
            case 3:
                nombre = "Vertice 4";
                break;
            case 4:
                nombre = "Vertice 5";
                break;
            case 5:
                nombre = "Vertice 6";
                break;
            case 6:
                nombre = "Vertice 7";
                break;
            case 7:
                nombre = "Vertice 8";
                break;
            case 8:
                nombre = "Vertice 9";
                break;
        }
        return nombre;
    }

    public void caminoMaximo() {
        for (int i = 0; i < n; i++) {
            visitados[i] = false;
            costosMaximos[i] = (matriz[s][i] != GrafoMat.num) ? matriz[s][i] : Integer.MIN_VALUE;
            ultimo[i] = s;
        }
        visitados[s] = true;
        costosMaximos[s] = 0;

        for (int i = 0; i < n - 1; i++) {
            int vertice = maximo(); // Selecciona vértice

            visitados[vertice] = true;

            for (int w = 0; w < n; w++) {
                if (!visitados[w] && matriz[vertice][w] != GrafoMat.num) {
                    if (costosMaximos[vertice] + matriz[vertice][w] > costosMaximos[w]) {
                        costosMaximos[w] = costosMaximos[vertice] + matriz[vertice][w];
                        ultimo[w] = vertice;
                    }
                }
            }
        }
    }

    public int maximo() {
        int max = Integer.MIN_VALUE;
        int vertice = -1;
        for (int j = 0; j < n; j++) {
            if (!visitados[j] && costosMaximos[j] >= max) {
                max = costosMaximos[j];
                vertice = j;
            }
        }
        return vertice;
    }

    public String recuperarCamino(int vertice) {
        if (vertice == s) {
            return casosNodos(s);
        } else {
            return recuperarCamino(ultimo[vertice]) + "->" + casosNodos(vertice);
        }
    }

    public int getCostosMaximos(int destino) {
        return costosMaximos[destino];
    }
}
