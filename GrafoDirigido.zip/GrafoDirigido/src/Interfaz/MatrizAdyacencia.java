package Interfaz;

import Logica.GrafoMatriz;

import javax.swing.table.DefaultTableModel;

public class MatrizAdyacencia extends javax.swing.JPanel {

    DefaultTableModel modelo = new DefaultTableModel();

    public MatrizAdyacencia(GrafoMatriz<String> grafo) {
        initComponents();

        mostrarMatrizAdyacencia(grafo);

    }
    /*
        public GrafoMatriz<String> crear(GrafoMat<String> grafo) {

            grafo.insertarVertice("Plaza Imperial"); //0
            grafo.insertarVertice("Portal 80"); //1
            grafo.insertarVertice("Diverplaza"); //2
            grafo.insertarVertice("Titan Plaza"); //3
            grafo.insertarVertice("Nuestro Bogota"); //4
            grafo.insertarVertice("Hayuelos"); //5
            grafo.insertarVertice("Multiplaza"); //6
            grafo.insertarVertice("El Eden"); //7
            grafo.insertarVertice("Plaza Central"); //8
            grafo.insertarVertice("Centro Mayor"); //9
            grafo.insertarVertice("El Ensueño"); //10
            grafo.insertarVertice("Mercurio"); //11
            grafo.insertarVertice("UMB"); //12

            //Plaza Imperial
            grafo.insertarArista(0, 9, 23);
            grafo.insertarArista(0, 1, 7);//7.2
            grafo.insertarArista(0, 5, 12);
            grafo.insertarArista(0, 7, 16);
            grafo.insertarArista(0, 3, 8);//8.2

            //Portal 80
            grafo.insertarArista(1, 2, 3);//2.7
            grafo.insertarArista(1, 4, 5);//5.3
            grafo.insertarArista(1, 9, 45);

            //Diverplaza
            grafo.insertarArista(2, 3, 5);//4.8
            grafo.insertarArista(2, 4, 3);//3.4
            grafo.insertarArista(2, 10, 49);
            grafo.insertarArista(2, 11, 24);

            //Titan Plaza
            grafo.insertarArista(3, 4, 8);//7.6
            grafo.insertarArista(3, 6, 8); //8.2
            grafo.insertarArista(3, 8, 10); //9.6

            //Nuestro Bogota
            grafo.insertarArista(4, 5, 3);//3.1
            grafo.insertarArista(4, 8, 8);//8.1

            //Hayuelos
            grafo.insertarArista(5, 6, 2);//2.3
            grafo.insertarArista(5, 7, 4);//3.5
            grafo.insertarArista(5, 11, 18);

            //Multiplaza
            grafo.insertarArista(6, 7, 3);//2.5

            //El Eden
            grafo.insertarArista(7, 8, 3);//3.2
            grafo.insertarArista(7, 10, 10);
            grafo.insertarArista(7, 11, 15);

            //Plaza Central
            grafo.insertarArista(8, 9, 7);//6.9
            grafo.insertarArista(8, 10, 9);//8.7
            grafo.insertarArista(8, 11, 16);

            //Centro Mayor
            grafo.insertarArista(9, 10, 6);//5.9
            grafo.insertarArista(9, 11, 11);//5.9

            //El Ensueño
            grafo.insertarArista(10, 11, 7);

            return grafo;
        }
    */
    public void mostrarMatrizAdyacencia(GrafoMatriz<String> grafo) {
        int[][] matriz = grafo.obtenerMatrizAdyacencia();
        int n = grafo.orden();
        String[] columna = new String[n];
        for (int i = 0; i < n; i++) {
            columna[i] = grafo.obtenerVertice(i);
        }

        DefaultTableModel modelo = new DefaultTableModel();
        tbl_Matriz.setModel(modelo);

        // Agregar las columnas al modelo
        for (String col : columna) {
            modelo.addColumn(col);
        }

        // Agregar las filas al modelo
        for (int i = 0; i < n; i++) {
            Object[] fila = new Object[n];
            for (int j = 0; j < n; j++) {
                fila[j] = matriz[i][j];
            }
            modelo.addRow(fila);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jFrame2 = new javax.swing.JFrame();
        jFrame3 = new javax.swing.JFrame();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Matriz = new javax.swing.JTable();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
                jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
                jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
                jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
                jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame3Layout = new javax.swing.GroupLayout(jFrame3.getContentPane());
        jFrame3.getContentPane().setLayout(jFrame3Layout);
        jFrame3Layout.setHorizontalGroup(
                jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame3Layout.setVerticalGroup(
                jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 300, Short.MAX_VALUE)
        );

        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Matriz Adyacencia");

        tbl_Matriz.setModel(new DefaultTableModel(
                new Object [][] {
                        {null, null, null, null},
                        {null, null, null, null},
                        {null, null, null, null},
                        {null, null, null, null}
                },
                new String [] {
                        "Title 1", "Title 2", "Title 3", "Title 4"
                }
        ));
        jScrollPane1.setViewportView(tbl_Matriz);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(431, 431, 431)
                                                .addComponent(jLabel1))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(77, 77, 77)
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 924, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(74, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31))
        );
    }// </editor-fold>


    // Variables declaration - do not modify
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JFrame jFrame3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_Matriz;
    // End of variables declaration
}