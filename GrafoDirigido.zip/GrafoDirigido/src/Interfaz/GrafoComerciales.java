package Interfaz;

import Logica.Grafo;
import Logica.GrafoMat;
import Logica.GrafoMatriz;

import javax.swing.*;
import java.awt.*;

public class GrafoComerciales extends javax.swing.JFrame {

    private GrafoMatriz<String> grafo = new GrafoMat<>();
    private GrafoMatriz<String> grafoMatriz;
    private Grafo grafoLista;
    FondoPanel fondo = new FondoPanel();

    public GrafoComerciales(GrafoMatriz<String> Grafo, GrafoMatriz<String> GrafoMatriz, Grafo grafoLista) {
        this.setContentPane(fondo);
        initComponents();
        setIconImage(getIconImage());
        this.setLocationRelativeTo(this);
        this.setTitle("GRAFOS CENTROS COMERCIALES");
        this.grafoMatriz = GrafoMatriz;
        this.grafo = Grafo;
        this.grafoLista=grafoLista;

        MostrarGrafo mostrarGrafo = new MostrarGrafo((GrafoMat<String>) grafo);
        mostrarGrafo.setSize(1076, 531);
        mostrarGrafo.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarGrafo, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        content = new javax.swing.JPanel();
        btn_Gijkstra = new javax.swing.JButton();
        btn_Maximos = new javax.swing.JButton();
        btn_Warshall = new javax.swing.JButton();
        btn_Grafo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btn_Matriz = new javax.swing.JButton();
        btn_listaAdyacencias = new javax.swing.JButton();
        btn_anchura = new javax.swing.JButton();
        btn_profundidad = new javax.swing.JButton();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 102));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        content.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1076, Short.MAX_VALUE)
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 531, Short.MAX_VALUE)
        );

        btn_Gijkstra.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Gijkstra.setText("Costos Minimos");
        btn_Gijkstra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_GijkstraActionPerformed(evt);
            }
        });

        btn_Maximos.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Maximos.setText("Costos Maximos");
        btn_Maximos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_MaximosActionPerformed(evt);
            }
        });

        btn_Warshall.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Warshall.setText("Warshall");
        btn_Warshall.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_WarshallActionPerformed(evt);
            }
        });

        btn_Grafo.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Grafo.setText("Mostrar Grafo");
        btn_Grafo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_GrafoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("OCR A Extended", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("GRAFO DIRIGIDO DEL 1 AL 8 ");

        btn_Matriz.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_Matriz.setText("Matriz de Adyacencias");
        btn_Matriz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_MatrizActionPerformed(evt);
            }
        });

        btn_listaAdyacencias.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_listaAdyacencias.setText("Lista de Adyacencias");
        btn_listaAdyacencias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_listaAdyacenciasActionPerformed(evt);
            }
        });

        btn_anchura.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_anchura.setText("Anchura");
        btn_anchura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_anchuraActionPerformed(evt);
            }
        });

        btn_profundidad.setFont(new java.awt.Font("OCR A Extended", 0, 12)); // NOI18N
        btn_profundidad.setText("Profundidad");
        btn_profundidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_profundidadActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(112, 112, 112)
                .addComponent(content, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(btn_Grafo, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_Matriz, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_listaAdyacencias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_Gijkstra, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_Maximos, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_Warshall, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_anchura, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_profundidad, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 585, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(325, 325, 325))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(content, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_Warshall, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Maximos, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Gijkstra, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_listaAdyacencias, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Matriz, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Grafo, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(btn_anchura, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_profundidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_WarshallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_WarshallActionPerformed
        MostrarWarshall mostrarWarshall = new MostrarWarshall((GrafoMat<String>) grafo);
        mostrarWarshall.setSize(1076, 531);
        mostrarWarshall.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarWarshall, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_WarshallActionPerformed

    private void btn_MaximosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_MaximosActionPerformed

        MostrarMaximos mostrarMaximos = new MostrarMaximos((GrafoMat<String>) grafo);
        mostrarMaximos.setSize(1076, 531);
        mostrarMaximos.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarMaximos, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();

    }//GEN-LAST:event_btn_MaximosActionPerformed

    private void btn_GijkstraActionPerformed(java.awt.event.ActionEvent evt) {                                            
        MostrarDijkstra mostrarDijkstra = new MostrarDijkstra((GrafoMat<String>) grafo);
        mostrarDijkstra.setSize(1076, 531);
        mostrarDijkstra.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarDijkstra, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }                                            

    private void btn_MatrizActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_MatrizActionPerformed
        MatrizAdyacencia mostrarMatriz = new MatrizAdyacencia((GrafoMatriz<String>) grafoMatriz);
        mostrarMatriz.setSize(1076, 531);
        mostrarMatriz.setLocation(0, 0);
        content.removeAll();
        content.add(mostrarMatriz, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_MatrizActionPerformed

    private void btn_GrafoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_GrafoActionPerformed
        MostrarGrafo mostrarGrafo = new MostrarGrafo((GrafoMat<String>) grafo);
        mostrarGrafo.setSize(1076, 531);
        mostrarGrafo.setLocation(0, 0);

        content.removeAll();
        content.add(mostrarGrafo, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_GrafoActionPerformed

    private void btn_listaAdyacenciasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_listaAdyacenciasActionPerformed
        MostrarLista mostrarLista = new MostrarLista(grafoLista);
        mostrarLista.setSize(1076, 531);
        mostrarLista.setLocation(0,0);
        content.removeAll();
        content.add(mostrarLista, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_listaAdyacenciasActionPerformed

    private void btn_anchuraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_anchuraActionPerformed
        MostrarAnchura mostrarAnchura= new MostrarAnchura(grafoLista);
        mostrarAnchura.setSize(1076, 531);
        mostrarAnchura.setLocation(0,0);
        content.removeAll();
        content.add(mostrarAnchura, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btn_anchuraActionPerformed

    private void btn_profundidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_profundidadActionPerformed
        MostrarProfundidad mostrarProfundidad= new MostrarProfundidad(grafoLista);
        mostrarProfundidad.setSize(1076, 531);
        mostrarProfundidad.setLocation(0,0);
        content.removeAll();
        content.add(mostrarProfundidad, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();

    }//GEN-LAST:event_btn_profundidadActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Gijkstra;
    private javax.swing.JButton btn_Grafo;
    private javax.swing.JButton btn_Matriz;
    private javax.swing.JButton btn_Maximos;
    private javax.swing.JButton btn_Warshall;
    private javax.swing.JButton btn_anchura;
    private javax.swing.JButton btn_listaAdyacencias;
    private javax.swing.JButton btn_profundidad;
    private javax.swing.JPanel content;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables

    class FondoPanel extends JPanel {

        private Image imagen;

        public void paint(Graphics g) {
            imagen = new ImageIcon(getClass().getResource("/Imagenes/Fondo.jpeg")).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);

            super.paint(g);
        }
    }
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/Icono.jpeg"));
        return retValue;
    }
}
